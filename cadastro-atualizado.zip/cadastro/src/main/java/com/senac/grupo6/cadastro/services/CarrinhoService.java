package com.senac.grupo6.cadastro.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import com.senac.grupo6.cadastro.entities.CarrinhoDTO;
import com.senac.grupo6.cadastro.interfacefeign.CarrinhoFeignClient;

public class CarrinhoService {
	
	@Autowired
	CarrinhoFeignClient carrinhoFeignClient;
	@GetMapping()
	@CrossOrigin(origins="*")
	public ResponseEntity<CarrinhoDTO>listarCarrinhos(){
		return ResponseEntity.ok(carrinhoFeignClient.findById(1).getBody());
	}

}
